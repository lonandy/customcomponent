from .MyCustomComponent import MyCustomComponent

__all__ = [
    "MyCustomComponent"
]